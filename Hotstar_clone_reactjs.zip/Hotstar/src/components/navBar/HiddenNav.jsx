import React from "react";

const HiddenNav = (props)=>{
    return(
        <div className="hidden">
            <ul>
                 {props.data.map((i)=>{
                    return(
                        <li>{i}</li>
                    )
                 })}
            </ul>
        </div>
    )
}
export default HiddenNav