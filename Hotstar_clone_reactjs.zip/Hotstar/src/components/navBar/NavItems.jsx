import React from "react";

const NavItems = ()=>{
    
    return(
        <ul>
            <li><i class="fa-solid fa-user"></i><p>My Space</p></li>
            <li><i class="fa-solid fa-magnifying-glass"></i><p>Search</p></li>
            <li><i class="fa-solid fa-house"></i><p>Home</p></li>
            <li><i class="fa-solid fa-tv"></i><p>TV</p></li>
            <li><i class="fa-solid fa-video"></i><p>Movies</p></li>
            <li><i class="fa-solid fa-baseball"></i><p>Sports</p></li>
            <li><i class="fa-solid fa-list"></i><p>Categories</p></li>
        </ul>
    )
}
export default NavItems