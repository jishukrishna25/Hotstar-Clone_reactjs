import React from "react";
import NavItems from "./NavItems";
import HiddenNav from "./HiddenNav";

const Nav =()=>{

    let navRight = ["My Space", "Search", "Home", "TV", "Movies", "Sports", "Categories"]
    return(
        <div className="nav">
            <div className="logo">
                <img src="https://img.hotstar.com/image/upload/v1656431456/web-images/logo-d-plus.svg" alt="" />
            </div>
            <div className="navBottom">
                <NavItems/>
            </div>
        </div>
    )
}
export default Nav