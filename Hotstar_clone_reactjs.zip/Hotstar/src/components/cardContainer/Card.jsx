import React from "react";

const Card =(props)=>{


    console.log(props.data.mName);

    return(
        <div className="card" title= {props.data.mName}>
            <div className="cardIMG">
                <img src= {props.data.poster} alt="" />
            </div>

        </div>
    )
}
export default Card