import React from "react";
import Card from "./Card";

const CardContainer =()=>{
    const arrMovie = [
       {mName:"LEAVE NO TRACE",poster:"https://resizing.flixster.com/2yN-8dHeqIS7_yy8-s7K46jlsus=/206x305/v2/https://resizing.flixster.com/qF1V53LvHZfdeJGYQt0E8jsTVg0=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzIyMWNhY2M3LWZjMTItNDdmOS1iYjZjLTM2NmVlNzA4NDc5NC53ZWJw"},
       {mName:"TOY STORY 2",poster:"https://resizing.flixster.com/sr_zocExK7yU80gVJJuVeahl9vs=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p24266_p_v12_ae.jpg"},
       {mName:"MAN ON WIRE",poster:"https://resizing.flixster.com/Wv_Km_cCIyxIXeMmRP-Xgpmsdd0=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p179858_p_v8_ag.jpg"},
       {mName:"HONEYLAND",poster:"https://resizing.flixster.com/P8IlcXOUtCRYLBYwJJt8H5e_mEg=/206x305/v2/https://resizing.flixster.com/VQ1CPyV8p18AhEgs7yjEAlDgwkc=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzdlNzgyODhmLWNkMjAtNGY4ZS05NjI4LWJjYzFhMTJlODUxZi53ZWJw"},
       {mName:"MINDING THE GAP",poster:"https://resizing.flixster.com/X4DV2oVY5r6Mnt2LsVYyTAqgBrw=/206x305/v2/https://resizing.flixster.com/PrqZIWSK1nQ-hr8YOvQgvESiI7g=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzU3OGRiM2Y1LWY5OGEtNDNhMC1hODE2LTlhY2RiNGU1OGZkNC53ZWJw"},
       {mName:"HIS HOUSE",poster:"https://resizing.flixster.com/DQoCszCoxbLp2vyLuTUDOgKHqWw=/206x305/v2/https://resizing.flixster.com/OnI40v_5iaeMcxv03WYplHl5l_8=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2UzY2U2OGZiLTBlN2UtNDUxMi1iMmI0LTFkYTFiYzBlYzA1MC5qcGc="},
       {mName:"THE PHILADELPHIA STORY",poster:"https://resizing.flixster.com/e6TG9SIMkrUuRzqSggSNoG9tc4g=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p4770_p_v8_ab.jpg"},
       {mName:"76 DAYS",poster:"https://resizing.flixster.com/WrKjIqHFBh5XeUuVCm1YqyYo6AI=/206x305/v2/https://resizing.flixster.com/UMYCpfQkWEDJhT2kT8BGAsX08Yc=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JkNjU3OTRkLWIzNmEtNDc3OS04Y2I2LWZmYjU4ZmQ0YWZiOC5qcGc="},
       {mName:"CRIP CAMP ",poster:"https://resizing.flixster.com/aDLipUpSWvvWCZsByereXshkeQc=/206x305/v2/https://resizing.flixster.com/7dM67xYtgyd69ydqqhbdwgW7ACw=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2FhZTUxZGU5LTE3MDctNGI0Ni05MzI4LTQ2NmEwN2IwYzYwMS53ZWJw"},
       {mName:"SUMMER 1993",poster:"https://resizing.flixster.com/Ej30XqOvcuRJehEKGRMt22CKB-c=/206x305/v2/https://resizing.flixster.com/6eRVq5JaL2z-GW-V4FFKVkkKwec=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzA3YjAxZjMxLTMyYjAtNDkxMC1hYWY3LWUzNmQxNTJjMzM3Ny53ZWJw"},
       {mName:"THE TALE OF THE PRINCESS KAGUYA ",poster:"https://resizing.flixster.com/QxSBCZgv-GnKAuOEwWMqobl4znI=/206x305/v2/https://resizing.flixster.com/V6fuiKhOSPH5q8o4P2iyc4atBJo=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2IwMTljZTJlLWI2YjAtNGQzNy1hNWQxLTU3ZWNlNzc5YmRjYy5qcGc="},
       {mName:"TOY STORY",poster:"https://resizing.flixster.com/Q_eOheUnRt1L271Ow8RG-jNDqOk=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p17420_p_v12_bc.jpg"},
       {mName:"ONE CUT OF THE DEAD ",poster:"https://resizing.flixster.com/X8dTBYlAG97G1evyh-ktP83Wxwg=/206x305/v2/https://resizing.flixster.com/We7GHCeHa3IXIaWs7WxEbVI5iwM=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzIwMzg0NWIyLTkzMTgtNDUxNC05NjVmLTM5MGY1NjMyNTU3MS53ZWJw"},
       {mName:"NO BEARS",poster:"https://resizing.flixster.com/3cufsVnGbGa1TBoPympoFTU_-UQ=/206x305/v2/https://resizing.flixster.com/oUBxvoxvFBE_kqBF26yH2Yh3s6w=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzQ0YTJlZmQxLTg5MDktNDlhNi04MDlhLWE5NmU1NmFiN2U4Ni5qcGc="},
       {mName:"SEVEN SAMURAI",poster:"https://resizing.flixster.com/fsIHET3BY_Zb2AwbXhF6RhFAHuk=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p5588_p_v8_au.jpg"},
       {mName:"TAXI TO THE DARK SIDE",poster:"https://resizing.flixster.com/yl_cYvjDQLBuENVy6_ZMhCLiGWU=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p170785_p_v10_aa.jpg"},
       {mName:"GETT: THE TRIAL OF VIVIANE AMSALEM",poster:"https://resizing.flixster.com/z6v3vlsWo4Itw_1DJaZajG3h8Eo=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p11127290_p_v8_ab.jpg"},
       {mName:"SINGIN' IN THE RAIN",poster:"https://resizing.flixster.com/LSubsV0mIxlC2j_GS9ChMnLfC5Y=/206x305/v2/https://resizing.flixster.com/ygT6OP8ylOtWO0fxP73DGw9yMZg=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzA2MWJiMDlmLTJiNzAtNDg3OS04ZTk1LTI0OGMzYzE0OTRmNy53ZWJw"},
       {mName:"WELCOME TO CHECHNYA",poster:"https://resizing.flixster.com/fBEe2205KIG75nsjnIcbJXlk-OM=/206x305/v2/https://resizing.flixster.com/H8SIQDQ0N3DWlZwWlA2QY-YR5dc=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzUwNzFlMzdmLWU2NDEtNGVjZS04MjJiLTU3NDAxMzZkY2FkMC53ZWJw"},
       {mName:"HIVE",poster:"https://resizing.flixster.com/p68x9yf52jMP73INJh1sYzwNPHg=/206x305/v2/https://resizing.flixster.com/xDzSw2ochJkdg4Uf_s4drslTnpA=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzcxMGQwNzc4LWNjMzktNGM1OC04MWVhLTc2MjlmOWRmYjM4YS5qcGc="},
       {mName:"DELIVER US FROM EVIL",poster:"https://resizing.flixster.com/do7t2AVEcvSlNR72aHqrXyem2iY=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p163135_p_v8_aa.jpg"},
       {mName:"POETRY",poster:"https://resizing.flixster.com/2C58rE3XQ91K5x3xZYswmm_rPZI=/206x305/v2/https://resizing.flixster.com/1G3nD43dJ8isGbMJqm0MHj4FGyk=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2NiZTQ4MmYyLWY2NTUtNGZjOC04ZmY5LTlkZjhkMDliYWFlOC5qcGc="},
       {mName:"WASTE LAND",poster:"https://resizing.flixster.com/VYuLAsQFkjduXOwvSsbZhwLgcPY=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p8361167_p_v13_ac.jpg"},
       {mName:"THE SQUARE ",poster:"https://resizing.flixster.com/WMypME4c6t3Nqhx6vrz6rUyyouY=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p10239700_p_v8_aa.jpg"},
       {mName:"SEYMOUR: AN INTRODUCTION",poster:"https://resizing.flixster.com/CyrdRjKH-SweOI7eHd7bPU9Wygc=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p11435588_p_v8_ab.jpg"},
       {mName:"ALL IN: THE FIGHT FOR DEMOCRACY",poster:"https://resizing.flixster.com/fQYcwz9f3DGWYk77DFlABD3RckA=/206x305/v2/https://resizing.flixster.com/0hAuRmji3kHh2OhCcm9IHLxOvrQ=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzg0NGM5NmNhLWExYzQtNDcwMC04YTY4LTNmZWUzYzNhZTU2MC5qcGc="},
       {mName:"THE TERMINATOR",poster:"https://resizing.flixster.com/Rxyp_L2fOqiEItaXust7ITlebpw=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p7764_p_v8_au.jpg"},
       {mName:"LAURA",poster:"https://resizing.flixster.com/UZL3W-FekPoFDADM-mYtf0JIEbI=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p212_p_v8_aa.jpg"},
       {mName:"MUCHO MUCHO AMOR: THE LEGEND OF WALTER MERCADO",poster:"https://resizing.flixster.com/-x0ZAnVRtClF2fdp_Lohk6dWwbg=/206x305/v2/https://resizing.flixster.com/SLqzXhSy8WNSyu1MiYNQIfzo8GY=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzMwOTIyYTZhLTkxZTEtNDY0Ny1iNTRlLThjYmMzMTM3YjEzZS53ZWJw"},
       {mName:"STILL WALKING",poster:"https://resizing.flixster.com/savHXHnWQayv726GVVuf_kRPtgY=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p190706_p_v8_aa.jpg"},
       {mName:"AFGHAN STAR",poster:"https://resizing.flixster.com/M6FV0WJCFB6WrVkfyyQUCVS2_Q4=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p197200_v_v10_ab.jpg"},
       {mName:"DAWSON CITY: FROZEN TIME",poster:"https://resizing.flixster.com/E4HA_J19LEuIPhmW0HXfzvQfUAQ=/206x305/v2/https://resizing.flixster.com/ZcBn9BY5vxX7zOXJyxMmcL0YFos=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2QwYzQ3ZmNlLTQyNzAtNGY4NS05M2M1LWViM2M2Nzk3NjdmOS53ZWJw"},
       {mName:"THE LAST PICTURE SHOW",poster:"https://resizing.flixster.com/qZR89WNK_Qo3oxbKX2n5hrbISHA=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p4046_p_v13_af.jpg"},
       {mName:"M",poster:"https://resizing.flixster.com/rVDuqcxlvS8She3LzNQxF7ViKNg=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p967_p_v8_ab.jpg"},
       {mName:"SLALOM",poster:"https://resizing.flixster.com/-SREm3GJEz9cl6FqmuEC8c4wgvI=/206x305/v2/https://resizing.flixster.com/IYWuTuE5kFH0htL5wv0QcSYkSlc=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2NiNTEzNDgwLWVkOGEtNDI1OC05MDVjLTYyNjIwNDg3NzcwMS5qcGc="},
       {mName:"12 ANGRY MEN",poster:"https://resizing.flixster.com/FDNKxkwCqhqdzh-IvaGBfzqRb74=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p2084_p_v8_ar.jpg"},
       {mName:"PINOCCHIO",poster:"https://resizing.flixster.com/W_MRcFFgKhwhONWn4CcoiS-uQtA=/206x305/v2/https://resizing.flixster.com/9DS4LnhK6sKEfJRY6N2wkOJooII=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzYwODY2MjRjLTc3OGEtNDIyMS05MDJjLTE2MjE0YjY2NDY0Zi5qcGc="},
       {mName:"ONLY YESTERDAY",poster:"https://resizing.flixster.com/Cwdkbh4zIgIJvKeY8CvVIBAAIXY=/206x305/v2/https://resizing.flixster.com/GMXOIc2qji2sLUuSxsvngLTkb3M=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2JlNWVkYTQ2LWVjN2EtNDE0ZS1hZjkzLTcxNzFmNzJhMTc3YS53ZWJw"},
       {mName:"THREE COLORS: RED",poster:"https://resizing.flixster.com/Fs8G7RQ93KfIDW6DjO5ZbgoX7oQ=/206x305/v2/https://resizing.flixster.com/Pl_61Y7SwszHBWRGtnhUbOvBUp8=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzYyYjhiZGVlLTI0ZTgtNGI2Yi05OWU4LWFjYTk1NzFkNzA0Yi5qcGc="},
       {mName:"THE WORK",poster:"https://resizing.flixster.com/XZigRk0_8kwywDGsYwCulIFdZ3A=/206x305/v2/https://resizing.flixster.com/BQ4sJcHEUI0BrueAWVtGhb_tOnY=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzQ5NTI4ZjMyLTRkNTktNDI4ZC04YjUzLTk5Yjg4MGUwZGJhMi53ZWJw"},
       {mName:"BRIGHT LIGHTS: STARRING CARRIE FISHER AND DEBBIE REYNOLDS",poster:"https://resizing.flixster.com/aOnf-iXWIxqh7TJ6FyYntWIPNTY=/206x305/v2/https://resizing.flixster.com/t04ywon3faeMI6emWzmrmIj4oak=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzVkZTRjNTZhLWQzZDMtNDI5ZC05MTNkLTM5NTVjZGQyNTUzOC53ZWJw"},
       {mName:"ATTICA",poster:"https://resizing.flixster.com/5_bi_cCTupCiXUOR_urN-jSf2nQ=/206x305/v2/https://resizing.flixster.com/V4FfswvfnLd-DY0kwLCATPjd510=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2E1Zjg2ZDY3LWMwZjEtNDQ5MS05MDY3LWRkYThmOTIyZjk2NC5qcGc="},
       {mName:"LAST TRAIN HOME",poster:"https://resizing.flixster.com/VKtzEmgeNhFXCcucOyoMpgWdJi4=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p7935080_p_v10_aa.jpg"},
       {mName:"TAMPOPO",poster:"https://resizing.flixster.com/dRGsaBfZzmxJcEwMIIlgO1DkxlQ=/206x305/v2/https://resizing.flixster.com/-HFI7qpdtUTjnT11HaJanBrx1Jg=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2RiZTZhMjQ3LWJkY2YtNGRjMC05ZDQ2LTViZjQyMWNhYmNiOS53ZWJw"},
       {mName:"THE TREASURE OF THE SIERRA MADRE",poster:"https://resizing.flixster.com/F6jpA5A2kWU9C_g05X5wihlvnxc=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p309_p_v8_aa.jpg"},
       {mName:"O.J.: MADE IN AMERICA ",poster:"https://resizing.flixster.com/29iKvKqRkJLFSxZ6ikXeNblL_yQ=/206x305/v2/https://resizing.flixster.com/kiZjIQugUsgqf3yxOX1bwDbT6aw=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2Q2YzhmYWY2LTUyZDYtNDNkMC1hOTUyLTQ1OWFmODA3NjVjNy53ZWJw"},
       {mName:"CHAINED FOR LIFE",poster:"https://resizing.flixster.com/lVtXa8KUysiAjXvTSUWlK6UPDO0=/206x305/v2/https://resizing.flixster.com/FzoHMcBs3Qrg4L0Rue1i4h8gW2o=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzLzQ0MWZmNDc4LTFiMzktNDQ2MC1iYzI5LWZmZmI4ZjMyM2Q1Yi53ZWJw"},
       {mName:"CODED BIAS",poster:"https://resizing.flixster.com/4lOW0Arj5JXf2mD_cFw4na0CVU0=/206x305/v2/https://resizing.flixster.com/oHbUX9KvteSG5lVscIEFPNJPl2U=/ems.cHJkLWVtcy1hc3NldHMvbW92aWVzL2I2MzA3MjE0LWFlN2EtNGE4ZC1hODEwLTM3ZjFkNjRlNDIxYi53ZWJw"}
       
    ]
    return(
        <div className="cardContainer">
            
            {arrMovie.map((i)=>{
                return(
                    <Card data={i}/>
                )
            })}
        </div>
    )
}
export default CardContainer