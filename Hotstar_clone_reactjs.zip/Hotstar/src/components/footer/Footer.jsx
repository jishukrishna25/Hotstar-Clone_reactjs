import React from "react";

const Footer = () => {
    return (
        <footer>
            <div className="listOne">
                <h3>Company</h3>
                <ul>
                    <li>About Us</li>
                    <li>careers</li>
                    <li>&copy; 2024 SaiNaivedya,All rights reserved</li>
                </ul>
            </div>
            <div className="listTwo">
                <h3>View website in</h3>
                <p>&#x1F4A5; English</p>

            </div>
            <div className="listThree">
                <h3>Need Help? <i class="fa-brands fa-hire-a-helper"></i> </h3>
                <ul>
                    <li>View help center</li>
                    <li>Share feedback</li>
                </ul>
            </div>
            <div className="listFour">
                <h3>Connect with us <i class="fa-solid fa-mobile"></i></h3>
                <ul>
                    <li><i class="fa-brands fa-facebook-f"></i></li>
                    <li><i  class="fa-brands fa-square-x-twitter"></i></li>
                    <li><i class="fa-brands fa-telegram"></i></li>
                </ul>
                <div className="images">
                    <div className="imgOne">
                        <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_256/v1661346101/google-playstore" alt="" />
                    </div>
                    <div className="imgTwo">
                        <img src="https://img10.hotstar.com/image/upload/f_auto,q_90,w_3840/v1661346071/ios-appstore" alt="" />
                    </div>
                </div>
            </div>
        </footer>
    )
}
export default Footer