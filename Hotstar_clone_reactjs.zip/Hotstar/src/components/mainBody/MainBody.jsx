import React from "react";
import Details from "./Details";
import CardContainer from "../cardContainer/CardContainer";
import Nav from "../navBar/Nav";
import Footer from "../footer/Footer";

const MainBody=()=>{

    return(
        <div className="mainBody">
            <Nav/>
            <Details/>
            <CardContainer/>
            <Footer/>
        </div>
    )
}
export default MainBody