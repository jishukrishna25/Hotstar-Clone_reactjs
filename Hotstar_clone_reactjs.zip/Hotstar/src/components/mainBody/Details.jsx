import React from "react";

const Details =()=>{
    return(
        <div className="details">
        <div className="info1">
            <p>2018 •</p>
            <p>2h7m •</p>
            <p>Hindi</p>
        </div>

        <div className="info2">
            <p>The small town of Chanderi is haunted by a vengeful spirit,Stree.Soon enough, Vicky, a goofy, gifted tailor, becomes an unlikely saviour for his kind. </p>
        </div>

        <div className="info3">
            <p>Horror |</p>
            <p>Paranormal |</p>
            <p>Dark |</p>
            <p>Supernatural</p>
        </div>

        <div className="info4">
            <div className="sub">
                <p><i class="fa-solid fa-play"></i> Subscribe to Watch</p>
            </div>
            <div className="add">
                <p>+</p>
            </div>
        </div>

        </div>
    )
}
export default Details