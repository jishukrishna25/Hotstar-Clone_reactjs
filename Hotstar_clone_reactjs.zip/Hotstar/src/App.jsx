import React from "react";
import MainBody from "./components/mainBody/MainBody";
import "./style.css"
const App = ()=>{
    return(
        <div className="app">
            <MainBody/>
        </div>
    )
}
export default App